package com.mitocode.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mitocode.model.Consulta;

public interface IConsultaDAO extends JpaRepository<Consulta, Integer> {

	@Query("from Consulta c where c.paciente.dni =:dni or LOWER(c.paciente.nombres) like %:nombreCompleto% or LOWER(c.paciente.apellidos) like %:nombreCompleto%")
	List<Consulta> buscar(@Param("dni")String dni, @Param("nombreCompleto")String nombreCompleto);
	
	@Query("from Consulta c where c.fecha between :fechaConsulta and :fechaSgte")
	List<Consulta> buscarFecha(@Param("fechaConsulta") LocalDateTime fechaConsulta, @Param("fechaSgte") LocalDateTime fechaSgte);
	
	@Query(value = "select * from fn_listarResumen()", nativeQuery = true)
	//@Query(value = "select (count(*)) as cantidad, to_char(c.fecha, 'dd/MM/yyyy') as fecha from consulta c	group by c.fecha order by c.fecha asc", nativeQuery = true)
	List<Object[]> listarResumen();
	
	//cantidad    fecha
	//[1		,		27/09/2018]
	//[2		,		28/09/2018]
}
