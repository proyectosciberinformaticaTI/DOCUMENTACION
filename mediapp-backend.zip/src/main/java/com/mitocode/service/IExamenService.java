package com.mitocode.service;

import com.mitocode.model.Examen;

public interface IExamenService extends ICRUD<Examen>{

}
